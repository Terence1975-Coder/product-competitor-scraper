from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, HttpUrl
from typing import Optional
import pathlib

from .scraper import run_research

BASE_DIR = pathlib.Path(__file__).resolve().parent.parent
TEMPLATES_DIR = BASE_DIR / "app" / "templates"
STATIC_DIR = BASE_DIR / "app" / "static"

app = FastAPI(title="Product Competitor Scraper")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class ResearchInput(BaseModel):
    product: Optional[str] = None
    location: Optional[str] = None
    company_url: Optional[HttpUrl] = None
    max_results: int = 12


@app.get("/")
async def index():
    return FileResponse(TEMPLATES_DIR / "index.html")


@app.post("/api/research")
async def api_research(payload: ResearchInput):
    try:
        results, query_used = await run_research(
            product=(payload.product or "").strip(),
            location=(payload.location or "").strip(),
            company_url=str(payload.company_url) if payload.company_url else None,
            max_results=max(1, min(25, payload.max_results)),
        )
        return JSONResponse({
            "ok": True,
            "query": query_used,
            "count": len(results),
            "results": results,
        })
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)
