import asyncio
import re
from typing import List, Tuple, Optional, Dict
from urllib.parse import urlparse, urlencode

import httpx
from bs4 import BeautifulSoup

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0 Safari/537.36"
    ),
    "Accept-Language": "en-GB,en;q=0.9",
}

DUCKDUCKGO_HTML = "https://duckduckgo.com/html/"


def _clean_text(txt: str) -> str:
    if not txt:
        return ""
    txt = re.sub(r"\s+", " ", txt).strip()
    return txt


def domain_of(url: str) -> str:
    try:
        netloc = urlparse(url).netloc.lower()
        if netloc.startswith("www."):
            netloc = netloc[4:]
        return netloc
    except Exception:
        return url


async def fetch_html(client: httpx.AsyncClient, url: str, timeout: int = 15) -> str:
    r = await client.get(url, headers=HEADERS, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    return r.text


def extract_meta_overview(html: str) -> Tuple[str, str, str]:
    """Return (title, description, first_paragraph)."""
    soup = BeautifulSoup(html, "lxml")

    # Title candidates
    title = (
        soup.find("meta", property="og:title") or soup.find("meta", attrs={"name": "title"})
    )
    title_text = None
    if title and title.get("content"):
        title_text = _clean_text(title["content"])[:200]
    elif soup.title and soup.title.text:
        title_text = _clean_text(soup.title.text)[:200]

    # Description candidates
    desc = (
        soup.find("meta", attrs={"name": "description"})
        or soup.find("meta", property="og:description")
        or soup.find("meta", attrs={"name": "twitter:description"})
    )
    desc_text = _clean_text(desc["content"])[:400] if desc and desc.get("content") else ""

    # First meaningful paragraph
    para_text = ""
    for p in soup.find_all("p"):
        text = _clean_text(p.get_text(" "))
        if len(text) >= 60:
            para_text = text
            break

    return title_text or "", desc_text, para_text


def synthesize_overview(title: str, desc: str, para: str) -> str:
    base = desc or para or title or ""
    base = _clean_text(base)
    if len(base) > 360:
        base = base[:357].rstrip() + "…"
    return base


async def extract_keywords_from_company(client: httpx.AsyncClient, url: str) -> List[str]:
    try:
        html = await fetch_html(client, url)
        title, desc, para = extract_meta_overview(html)
        # Very simple keyword heuristic
        text = f"{title} {desc} {para}".lower()
        tokens = re.findall(r"[a-zA-Z][a-zA-Z\-]{2,}", text)
        common = {"and", "the", "for", "with", "from", "that", "your", "our", "are", "you", "this", "have", "has", "into"}
        freq: Dict[str, int] = {}
        for t in tokens:
            if t in common or len(t) < 3:
                continue
            freq[t] = freq.get(t, 0) + 1
        # Top 6 keywords
        top = sorted(freq.items(), key=lambda kv: kv[1], reverse=True)[:6]
        return [k for k, _ in top]
    except Exception:
        return []


async def duckduckgo_search(client: httpx.AsyncClient, query: str, max_results: int = 12):
    params = {
        "q": query,
        "kl": "uk-en",  # localize to UK
    }
    url = f"{DUCKDUCKGO_HTML}?{urlencode(params)}"
    html = await fetch_html(client, url)
    soup = BeautifulSoup(html, "lxml")

    results = []
    # Primary selector (SERP HTML may change over time)
    for res in soup.select("div.result, div.results_links, div.web-result"):
        a = res.select_one("a.result__a, a.result__title, a[href]")
        if not a:
            continue
        href = a.get("href")
        if not href or href.startswith("/"):
            continue
        title = _clean_text(a.get_text(" "))
        snippet_el = res.select_one("a.result__snippet, div.result__snippet, .result__snippet, .snippet")
        snippet = _clean_text(snippet_el.get_text(" ")) if snippet_el else ""
        results.append({
            "title": title,
            "url": href,
            "snippet": snippet,
        })
        if len(results) >= max_results * 2:
            break

    # Deduplicate by domain, keep first occurrences
    seen = set()
    deduped = []
    for r in results:
        d = domain_of(r["url"])
        if d in seen:
            continue
        seen.add(d)
        deduped.append(r)
        if len(deduped) >= max_results:
            break
    return deduped


async def fetch_overview_for_result(client: httpx.AsyncClient, item: Dict, product_terms: List[str]):
    try:
        html = await fetch_html(client, item["url"])  # may raise
        title, desc, para = extract_meta_overview(html)
        overview = synthesize_overview(title, desc, para)

        # Basic relevance filter: ensure at least one product term appears
        text = f"{title} {desc} {para}".lower()
        relevant = True
        if product_terms:
            relevant = any(term.lower() in text for term in product_terms if term)

        return {
            "title": title or item.get("title") or domain_of(item["url"]),
            "url": item["url"],
            "domain": domain_of(item["url"]),
            "overview": overview,
            "relevant": relevant,
        }
    except Exception:
        return None


async def run_research(product: str, location: str, company_url: Optional[str], max_results: int = 12):
    query_parts = []
    product_terms = []

    async with httpx.AsyncClient(timeout=20) as client:
        # If a company URL is provided, try to infer keywords from it
        if company_url:
            inferred = await extract_keywords_from_company(client, company_url)
            if inferred:
                product_terms.extend(inferred)

        # Merge explicit product terms, if any
        if product:
            product_terms.extend([t.strip() for t in re.split(r",|/|;|\|", product) if t.strip()])

        # Build search query
        base = " ".join(dict.fromkeys(product_terms)) or product or "company"
        if location:
            query_parts.append(base)
            query_parts.append(location)
        else:
            query_parts.append(base)
        # Enrich with synonyms to favour B2B pages
        query_parts.append("supplier OR provider OR vendor OR services")
        query = " ".join(query_parts)

        # Search
        serp = await duckduckgo_search(client, query, max_results=max_results)

        # Fetch each result concurrently
        tasks = [fetch_overview_for_result(client, item, product_terms) for item in serp]
        raw = await asyncio.gather(*tasks)

        # Filter, sort: relevant first, then by domain alpha
        cleaned = [r for r in raw if r]
        cleaned.sort(key=lambda x: (not x["relevant"], x["domain"]))

        # Limit to max_results
        final = cleaned[:max_results]
        return final, query
