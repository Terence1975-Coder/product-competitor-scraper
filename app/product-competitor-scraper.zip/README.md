# Product Competitor Scraper

A small FastAPI app that finds companies offering the same product, scoped by location, with a one-click Copy for each result (URL + overview).

## Quickstart

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
# open http://localhost:8000
```

## Notes
- Uses DuckDuckGo HTML results (no API key). Respect terms/robots.
- HTML structures change, so selectors may need tweaks over time.
